/*
package game.Characters;

import city.cs.engine.*;
import city.cs.engine.Shape;
import game.KeyHandler;
import org.jbox2d.common.Vec2;

public class Player {
    private final KeyHandler input;
    private final DynamicBody spaceCraft;

    //Velocities
    private float gravity = 10;
    private float horAcc = 0;
    private float maxHorVel = 10;
    private float maxVerVel = 10;
    private float horVel = 0;
    private float verVel = 0;
    private float friction = 0.9999f;

    public Player(World world, KeyHandler input){
        this.input = input;
        Shape spaceCraftShape = new PolygonShape(-0.02f,0.94f, 0.76f,0.55f, 1.26f,-0.67f, 1.18f,-0.85f, -1.17f,-0.85f, -1.27f,-0.66f, -0.79f,0.54f);
        this.spaceCraft = new DynamicBody(world, spaceCraftShape);
        Fixture spaceCraftFixture = new SolidFixture(spaceCraft, spaceCraftShape);
        spaceCraftFixture.setDensity(1000);
        this.spaceCraft.addImage(new BodyImage("data/SpaceCraft.png", 4));
        spaceCraft.getMass();
    }

    public void update(){
        this.horVel = this.horVel + this.horAcc;
        this.verVel = this.verVel - this.gravity;
        this.horVel = Math.max(Math.min(this.horVel, this.maxHorVel), -this.maxHorVel);
        this.verVel = Math.max(Math.min(this.verVel, this.maxVerVel), -this.maxVerVel);

        this.verVel = (input.isUpPressed()) ? 10 : this.verVel;


        if (input.isLeftPressed() && input.isRightPressed()){
            this.horVel = 0;
        }
        else if (input.isLeftPressed()){
            this.horAcc = -1;
        }
        else if (input.isRightPressed()){
            this.horAcc = 1;
        }
        else{
            this.horAcc = 0;
        }

        this.horVel = this.horVel * this.friction;
        this.spaceCraft.setLinearVelocity(new Vec2(this.horVel, this.verVel));
        this.spaceCraft.setAngularVelocity(0);
    }
} */