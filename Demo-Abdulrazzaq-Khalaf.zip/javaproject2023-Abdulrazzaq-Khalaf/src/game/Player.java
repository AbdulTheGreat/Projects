package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import game.KeyHandler;
import org.jbox2d.common.Vec2;

import javax.swing.*;

public class Player extends Walker{

    private static final Shape playershape = new PolygonShape(-0.02f,0.94f, 0.76f,0.55f, 1.26f,-0.67f, 1.18f,-0.85f, -1.17f,-0.85f, -1.27f,-0.66f, -0.79f,0.54f);
    private static final BodyImage image = new BodyImage("data/SpaceCraft.png", 4);

   // private static final int id = 0;

    private static int Credit = 0;



    private final KeyHandler input;

    //Velocities
    private final float gravity = 10;
    private float horAcc = 0;
    private final float maxHorVel = 10;
    private final float maxVerVel = 10;
    private float horVel = 0;
    private float verVel = 0;
    private final float friction = 0.9999f;



    public Player(World world,KeyHandler input) {

            super(world,playershape);
            this.addImage(image);
            this.input = input;
            setCredit(15);
        System.out.println(Player.getCredit());
        }

    public static int getCredit() {
        return Credit;
    }

    public static void setCredit(int credit) {
        Credit = credit;
    }
    public void update(){
        this.horVel = this.horVel + this.horAcc;
        this.verVel = this.verVel - this.gravity;
        this.horVel = Math.max(Math.min(this.horVel, this.maxHorVel), -this.maxHorVel);
        this.verVel = Math.max(Math.min(this.verVel, this.maxVerVel), -this.maxVerVel);

        this.verVel = (input.isUpPressed()) ? 10 : this.verVel;


        if (input.isLeftPressed() && input.isRightPressed()){
            this.horVel = 0;
        }
        else if (input.isLeftPressed()){
            this.horAcc = -1;
        }
        else if (input.isRightPressed()){
            this.horAcc = 1;
        }
        else{
            this.horAcc = 0;
        }

        this.horVel = this.horVel * this.friction;
        this.setLinearVelocity(new Vec2(this.horVel, this.verVel));
        this.setAngularVelocity(0);
    }
}