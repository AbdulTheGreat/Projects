package game;


import city.cs.engine.*;
import city.cs.engine.Shape;
import game.KeyHandler;
import org.jbox2d.common.Vec2;


public class Bullets extends DynamicBody {



    private final Shape shape;


    public Bullets(World w, Shape s, Shape shape) {
        super(w, s);
        this.shape = shape;
    }
}
