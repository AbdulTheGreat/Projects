package game;

import city.cs.engine.UserView;

public class GameView extends UserView {
    public GameView(GameWorld w, int width, int height) {
        super(w, width, height);
    }
}
