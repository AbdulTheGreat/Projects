package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.*;
import static game.Characters.Enemy.enemies;
import static game.Characters.Enemy.enemyShape;

import game.Characters.Enemy;
import game.Characters.Platforms;

public class GameWorld extends World {


    public GameWorld() {
        super();
        final JFrame frame = new JFrame() ;
        final KeyHandler input = new KeyHandler(frame, -2);


        //Populate the GameWorld with bodies (ex. platforms, collectibles, characters)

        // make the ground platform

        final Platforms ground = new Platforms(this, 15, 1, 0, -15);

        // make the left wall platform
        Shape wallShape = new BoxShape(0.5f, 18);
        StaticBody leftWall = new StaticBody(this, wallShape);
        leftWall.setPosition(new Vec2(-14.5f, 0));

        //make right wall platform

        StaticBody rightWall = new StaticBody(this, wallShape);
        rightWall.setPosition(new Vec2(14.5f, 0));


     // Make the Player main Character with an overlaping Image

        Player spaceCraft = new Player(this, input);
        spaceCraft.setPosition(new Vec2(7, -9));

        // make enemy objects from the class Enemy
        // making a list of enemies with various set positions and take enemyShape
        Enemy enemy1 = new Enemy(this, enemyShape);
        enemy1.setPosition(new Vec2(-6, 20));
        enemy1.addImage(new BodyImage("data/enemy1.png", 3));
        enemy1.setGravityScale(0.1f);

        Enemy enemy2 = new Enemy(this, enemyShape);
        enemy2.setPosition(new Vec2(-3, 30));
        enemy2.addImage(new BodyImage("data/enemy2.png", 3));
        enemy2.setGravityScale(0.1f);

        Enemy enemy3 = new Enemy(this, enemyShape);
        enemy3.setPosition(new Vec2(3, 40));
        enemy3.addImage(new BodyImage("data/enemy2.png", 3));
        enemy3.setGravityScale(0.1f);

        Enemy enemy4 = new Enemy(this, enemyShape);
        enemy4.setPosition(new Vec2(6, 50));
        enemy4.addImage(new BodyImage("data/enemy2.png", 3));
        enemy4.setGravityScale(0.1f);


       // for (Enemy enemy : enemies) {


       // }

      /*  //public static JFrame frameSetup (){
             //final JFrame frame = new JFrame("City Game");
            // UserView view = new UserView(world, 600, 600);
            //view.setForeground(Color.BLUE);
            GameView view = new GameView(this, 500, 500);


            frame.add(view);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationByPlatform(true);
            frame.setResizable(false);
            frame.pack();
            frame.setVisible(true);


            //optional: uncomment this to make a debugging view
            //JFrame debugView = new DebugViewer(this, 600, 600);
            */


       //Loop
        while (frame.isVisible()) {

            spaceCraft.update();
        }

        }
    }


// create enemies and implement them in the main and bring in enemy character ( overlaid image)
// creating enemies line 1
/*
        Enemy enemy = new Enemy(world,enemyShape);
        enemy.setPosition(new Vec2(0, 20));
        enemy.addImage(new BodyImage("data/enemy1.png",2));
        enemy.setGravityScale(0.1f);

        // create a whole of this same enemy on the same line using for loops

       // DynamicBody enemyA = new DynamicBody(world, enemyShape);
        Enemy enemy1 = new Enemy(world, enemyShape);
        enemy1.setPosition(new Vec2(-5, 20));
        enemy1.addImage(new BodyImage("data/enemy1.png",2));
        enemy1.setGravityScale(0.1f);




        // adding another enemy
        Enemy enemy2 = new Enemy(world);
        enemy2.setPosition(new Vec2(-4,11));
        enemy2.addImage(new BodyImage("data/Enemy2.png", 2));
        enemy2.setGravityScale(0.1f);

        // adding another enemy
        Enemy enemy3 = new Enemy(world);
        enemy3.setPosition(new Vec2(-6,30));
        enemy3.addImage(new BodyImage("data/Enemy3.png", 2));
        enemy3.setGravityScale(0.1f);


    */