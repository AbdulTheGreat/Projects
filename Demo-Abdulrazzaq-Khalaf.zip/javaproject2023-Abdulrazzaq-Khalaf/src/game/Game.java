package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import game.Characters.*;
import game.Player;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.contacts.Velocity;


import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static game.Characters.Enemy.enemies;
import static game.Characters.Enemy.enemyShape;

// Create a class Game
public class Game {

    // initialize a new Game
    public Game() {

        // make an empty world
        // World world = new World();
        GameWorld world = new GameWorld();
        // Make a view to look into the Game World

        //private JFrame frameSetup(GameWorld world){
        final JFrame frame = new JFrame("City Game");
        GameView view = new GameView(world,500, 500);

        // final JFrame frame = frameSetup((GameWorld) world);
        final KeyHandler input = new KeyHandler(frame, -2);

        // UserView view = new UserView(world, 600, 600);
        //view.setForeground(Color.BLUE);
        frame.add(view);

        // enable the frame to quit the application
        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
          // finally, make the frame visible
        frame.setVisible(true);



        //optional: uncomment this to make a debugging view
        JFrame debugView = new DebugViewer(world, 600, 600);
        //return frame;

          // start our game world simulation!
          world.start();

       /*   //Loop
          while (frame.isVisible()) {

              Player.update();
          }

        */
    }

    /** Run the game. */
    public static void main(String[] args) {
        new Game();

    }
}