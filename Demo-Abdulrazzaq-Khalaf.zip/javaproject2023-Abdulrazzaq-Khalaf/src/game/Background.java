/*
package game;


import city.cs.engine.*;
import city.cs.engine.Shape;


import java.awt.*;

public class Background {
private Background bGround;

   public Background(World world) {


        this.World = world;
        Shape worldShape = new BoxShape(600, 600);
        this.worldShape.T
        backgroundTexture = new Texture(Gdx.files.internal("images/background.png"));
        Texture bGround = new Texture(Gdx.files.internal("pbBackground.png"));
    }
} */


